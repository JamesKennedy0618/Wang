declare module "*.png";
declare module "*.svg";
declare module "*.jpeg";
declare module "*.jpg";
declare module "*.webp";
declare module "*.webm";
declare module "*.mp4";

declare module 'react-notifications';
declare module 'react-native-voice';

interface ComPropsObject {
  [key: string]: any
}