

interface AppointmentsObject {
	title: string
	desc: string
	dateTime: string
	price: string
	status: boolean
}

interface BuyingItemObject {
	title: string
	price: string
	time: string
	amount: number
	image: string
}