export const config = {
  DEBUG: false,

  BACKEND_URL: "https://seagull-guiding-warthog.ngrok-free.app", //"https://seagull-guiding-warthog.ngrok-free.app",
  FRONTEND_URL: "http://192.168.135.164:8081",
}